
QBCore = exports['qb-core']:GetCoreObject()

RegisterNetEvent('signlanguage:server:playTTS', function(text)
    local src = source
    local playerPed = GetPlayerPed(src)
    local coords = GetEntityCoords(playerPed)

    for _, playerId in pairs(QBCore.Functions.GetPlayers()) do
        local targetPed = GetPlayerPed(playerId)
        local targetCoords = GetEntityCoords(targetPed)
        local dist = #(coords - targetCoords)

        if dist <= 20.0 then
            TriggerClientEvent('signlanguage:client:playTTS', playerId, text, src)
        end
    end
end)
