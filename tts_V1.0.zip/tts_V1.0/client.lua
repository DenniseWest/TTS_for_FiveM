
local QBCore = exports['qb-core']:GetCoreObject()
local isSpeaking = false

local function PlayMouthAnimation()
    local ped = PlayerPedId()
    SetFacialIdleAnimOverride(ped, "mic_chatter", 0)
    SetFacialClipset(ped, "mood_talking_normal_1", 0)
end

local function StopMouthAnimation()
    local ped = PlayerPedId()
    ClearFacialIdleAnimOverride(ped)
    ClearFacialClipset(ped)
end

RegisterNetEvent('signlanguage:client:playTTS', function(text, speakerId)
    if speakerId == PlayerId() then return end

    SendNUIMessage({
        action = "playTTS",
        text = text
    })
end)

RegisterCommand("zn", function(source, args)
    local text = table.concat(args, " ")
    if text == "" then
        TriggerEvent('chat:addMessage', {
            color = {255, 0, 0},
            args = {"[Sign]", "Zadej zprávu! Například: /signsay Pomoc!"}
        })
        return
    end

    TriggerServerEvent('signlanguage:server:playTTS', text)

    TriggerEvent('chat:addMessage', {
        color = {255, 255, 255},
        args = {"[Sign]", text}
    })

    if speakerId == PlayerId() then return end

end, false)
