window.speechSynthesis.onvoiceschanged = () => {
    const voices = window.speechSynthesis.getVoices();
    // Najdi hlas Zira (ženský anglický hlas na Windows)
    window.selectedVoice = voices.find(v => v.name.toLowerCase().includes('zira')) || voices[0];
    console.log('Vybraný hlas:', window.selectedVoice.name);
};

window.addEventListener('message', (event) => {
    if (event.data.action === 'speak' && event.data.text) {
        const utterance = new SpeechSynthesisUtterance(event.data.text);
        utterance.voice = window.selectedVoice;
        utterance.lang = window.selectedVoice.lang;
        window.speechSynthesis.speak(utterance);
    }
});
