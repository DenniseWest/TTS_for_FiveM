
fx_version 'cerulean'
game 'gta5'

description 'Text to speech for players that cant speak themselves'
author 'Denisa_W'

server_scripts {
    'server.lua'
}

client_scripts {
    'client.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html'
}
